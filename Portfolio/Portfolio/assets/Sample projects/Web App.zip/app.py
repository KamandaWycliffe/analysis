from flask import Flask, render_template, request
import tensorflow as tf
import pandas as pd
import joblib

app = Flask(__name__) 

# load pre-trained model
model = tf.keras.models.load_model('credit_prediction_model.h5')

@app.route('/')
def home():
    return render_template('/index.html')

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == "POST":
        # get user input
        loan = float(request.form['loan'])
        mortdue = float(request.form['mortdue'])
        value = float(request.form['value'])
        reason = request.form['reason']
        job = request.form['job']
        yoj = float(request.form['yoj'])
        derog = float(request.form['derog'])
        delinq = float(request.form['delinq'])
        clage = float(request.form['clage'])
        ninq = float(request.form['ninq'])
        clno = float(request.form['clno'])
        debtinc = float(request.form['debtinc'])

        # create input dataframe
        input_df = pd.DataFrame({
            'LOAN': [loan],
            'MORTDUE': [mortdue],
            'VALUE': [value],
            'YOJ': [yoj],
            'DEROG': [derog],
            'DELINQ': [delinq],
            'CLAGE': [clage],
            'NINQ': [ninq],
            'CLNO': [clno],
            'DEBTINC': [debtinc]
        })

        # add dummy variables for reason and job
        if reason == 'DebtCon':
            input_df['REASON_DebtCon'] = 1
            input_df['REASON_HomeImp'] = 0
            input_df['REASON_Other'] = 0
        elif reason == "HomeImp":
            input_df['REASON_DebtCon'] = 0
            input_df['REASON_HomeImp'] = 1
            input_df['REASON_Other'] = 0
        else:
            input_df['REASON_DebtCon'] = 0
            input_df['REASON_HomeImp'] = 0
            input_df['REASON_Other'] = 1

        if job == 'Other':
            input_df['JOB_Mgr'] = 0
            input_df['JOB_Office'] = 0
            input_df['JOB_ProfExe'] = 0
            input_df['JOB_Sales'] = 0
            input_df['JOB_Self'] = 0
            input_df['JOB_Other'] = 1
        else:
            input_df['JOB_Mgr'] = 1 if job == 'Mgr' else 0
            input_df['JOB_Office'] = 1 if job == 'Office' else 0
            input_df['JOB_ProfExe'] = 1 if job == 'ProfExe' else 0
            input_df['JOB_Sales'] = 1 if job == 'Sales' else 0
            input_df['JOB_Self'] = 1 if job == 'Self' else 0
            input_df['JOB_Other'] = 0

        # make prediction
        prediction = model.predict(input_df)
        df = input_df.copy()
        df['outcome'] = prediction
        variable_names = df.columns
        input_df.to_csv("static/data/customer_data.csv", mode='a', header=False)
        pd.DataFrame(variable_names).to_csv('Variables.txt')
	
        #call preprocessDataAndPredict and pass inputs
        try:
            prediction = preprocessDataAndPredict(input_df)
            #pass prediction to template
            return render_template('/predict.html', prediction = prediction)
   
        except ValueError:
            return "Please Enter valid values"
  
        pass
    pass


def preprocessDataAndPredict(test_data):
    
    
     #load trained model
    trained_model = tf.keras.models.load_model('credit_prediction_model.h5')
    
    predict = trained_model.predict(test_data)

    return predict
    
    pass

if __name__ == '__main__':
    app.run(debug=False, port=9874)