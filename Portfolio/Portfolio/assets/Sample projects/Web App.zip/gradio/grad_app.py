
import pandas as pd
import gradio as gr

# define the function to make predictions
def predict_loan_approval(loan_amount, mortdue, prop_value, reason, job, yoj, derog, delinq, clage, ninq, clno, debtinc):
    # load the input data into a pandas dataframe
    input_df = pd.DataFrame({
        "LOAN": [loan_amount],
        "MORTDUE": [mortdue],
        "VALUE": [prop_value],
        "REASON_DebtCon": [int("DebtCon" in reason)],
        "REASON_HomeImp": [int("HomeImp" in reason)],
        "REASON_Other" :[int("Other" in reason)],
        "JOB_Mgr": [int("Mgr" in job)],
        "JOB_Office": [int("Office" in job)],
        "JOB_ProfExe": [int("ProfExe" in job)],
        "JOB_Sales": [int("Sales" in job)],
        "JOB_Self": [int("Self" in job)],
        "JOB_Other": [int("Other" in job)],
        "YOJ": [yoj],
        "DEROG": [derog],
        "DELINQ": [delinq],
        "CLAGE": [clage],
        "NINQ": [ninq],
        "CLNO": [clno],
        "DEBTINC": [debtinc]
    })
    # add dummy variables for reason and job
    if "DebtCon" in reason:
        input_df["REASON_DebtCon"] = 1
    else:
        input_df["REASON_DebtCon"] = 0
    if "HomeImp" in reason:
        input_df["REASON_HomeImp"] = 1
    else:
        input_df["REASON_HomeImp"] = 0
        
    if "Mgr" in job:
        input_df["JOB_Mgr"] = 1
    else:
        input_df["JOB_Mgr"] = 0
    if "Office" in job:
        input_df["JOB_Office"] = 1
    else:
        input_df["JOB_Office"] = 0
    if "Other" in job:
        input_df["JOB_Other"] = 1
    else:
        input_df["JOB_Other"] = 0
    if "ProfExe" in job:
        input_df["JOB_ProfExe"] = 1
    else:
        input_df["JOB_ProfExe"] = 0
    if "Sales" in job:
        input_df["JOB_Sales"] = 1
    else:
        input_df["JOB_Sales"] = 0
    if "Self" in job:
        input_df["JOB_Self"] = 1
    else:
        input_df["JOB_Self"] = 0
    
    # load the pretrained model
    model = tf.keras.models.load_model("credit_prediction_model.h5")

    # make a prediction
    prediction = model.predict(input_df)
    pred = prediction[0][0]
    # return the prediction as "Approved" or "Not Approved"
    if pred  > 0.3:
        return "Risk score: "+str(round(pred))+" :Decision: "+"Not Approved"
    else:
        return str(round(pred,4))+":"+"Approved" 


# define the Gradio interface
inputs = [
    gr.inputs.Number(label="Loan Amount (000)"),
    gr.inputs.Number(label="Amount due on Existing Mortgage"),
    gr.inputs.Number(label="Value of Current Property"),
    gr.inputs.CheckboxGroup(
        label="Reason",
        choices=["DebtCon", "HomeImp"]
    ),
    gr.inputs.CheckboxGroup(
        label="Job",
        choices=['Office', 'Sales', 'Mgr', 'ProfExe', 'Self','Other']
    ),
    gr.inputs.Number(label="Years at Present Job"),
    gr.inputs.Number(label="Number of Major Derogatory Reports"),
    gr.inputs.Number(label="Number of Delinquent Credit Lines"),
    gr.inputs.Number(label="Age of Oldest Credit Line in Months"),
    gr.inputs.Number(label="Number of Recent Credit Inquiries"),
    gr.inputs.Number(label="Number of Credit Lines"),
    gr.inputs.Number(label="Debt-to-Income Ratio")
]

outputs = gr.outputs.Textbox(label="Loan Approval")

iface = gr.Interface(
    fn=predict_loan_approval,
    inputs=inputs,
    outputs=outputs,
    title="Loan Approval Prediction",
    description="Enter the details of the loan application to check for eligibility",
    theme="dark" # default theme
)

iface.launch(share=False)
#iface.theme_toggle()